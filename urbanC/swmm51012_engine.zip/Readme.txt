Contents of this archive:

source5_1_012.zip
=================
Contains the source code for the computational engine
of SWMM 5.1.012. Consult the included Roadmap.txt file
for an overview of the various code modules.

makefiles.zip
=============
Contains "make" files for compiling the SWMM 5.1 engine
on Microsoft C++ 2010 and the GNU C compiler for Linux.